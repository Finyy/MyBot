﻿ What is it?
  -----------

## 使用指南
1. 下载bluestack  链接: http://pan.baidu.com/s/1mhaFjjM 密码: jkhq
2. 下载 vc++ 2010 x86  链接: http://pan.baidu.com/s/1mhki80g 密码: xpbf
3. 下载 net 4.5 链接: http://pan.baidu.com/s/1brU5xc 密码: xwiu
4. 进入coc 把语言设置成英文 (一定要设置不然不工作的)
5. 运行kunlun缩放.bat  不然coc 无法缩进

## 报毒须知
1. autoit 生成的程序 默认报毒的， 杀毒软件通病  杀易语言程序一样
2. 如果不放心的话使用vmware 
 
- A Free Clash of Clans bot. 
- A bot is a general term in gaming that is used to refer to a character controlled by a computer.
- https://mybot.run

The Latest Version
  ------------------
- Details of the latest version can be found on the MyBot forum under https://mybot.run/forums/thread-6924.html

Documentation
  -------------
- How to Start Bot - https://mybot.run/forums/showthread.php?tid=4
- How to Report Bug/Help - https://mybot.run/forums/showthread.php?tid=211

Installation
  ------------
Essential software :
- Windows Vista/7/8/8.1
- {Note - MyBot does not support Windows 10 at this time!} https://mybot.run/forums/thread-7296.html
- Microsoft Visual C++ 2010 Redistributable Package (x86)
- Microsoft .NET Framework 4.5
- BlueStacks App Player 0.9.24.5311 Superuser BSEasy ROOT by @swvr (Recommended)
- The latest drivers for your graphics device
- MyBot last version avaiable
- DON´T USE THE OLD CONFIG FILES

Licensing
  ---------
Please see the file called LICENSE.
- MyBot autoit code is open sourced under GNU GENERAL PUBLIC LICENSE v3
- http://www.gnu.org/licenses/gpl-3.0.txt

- Curl.exe - curl is an open source command line tool and library for transferring data with URL syntax, supporting DICT, FILE, FTP, FTPS, Gopher, HTTP, HTTPS, IMAP, IMAPS, LDAP, LDAPS, POP3, POP3S, RTMP, RTSP, SCP, SFTP, SMB, SMTP, SMTPS, Telnet and TFTP. curl supports SSL certificates, HTTP POST, HTTP PUT, FTP uploading, HTTP form based upload, proxies, HTTP/2, cookies, user+password authentication (Basic, Plain, Digest, CRAM-MD5, NTLM, Negotiate and Kerberos), file transfer resume, proxy tunneling and more. This executable is used in our software because Pushbullet.
  http://curl.haxx.se/

Mybot uses non-GPL 3rd party libraries for extension (#SystemLibraryException): 
- OpenCV - BSD license - repository : https://github.com/MyBotRun/Libraries
- ImageSearch - GNU license - repository : https://github.com/MyBotRun/Libraries
- Functional library MBRfunctions.dll - Proprietary library from the Developer Didipe 2015

Contacts
  --------
- https://mybot.run/forums/contact.php
